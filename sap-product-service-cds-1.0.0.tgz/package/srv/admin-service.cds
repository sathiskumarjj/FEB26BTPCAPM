using {sap.capire.products as database} from '../db/schema';

service AdminService {

    entity ProductSrv as projection on database.Products;

    entity CategoriesSrv as projection on database. Categories;
    
}